package org.zerock.study.domain.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.study.domain.DTO.PostDTO;
import org.zerock.study.domain.repository.PostRepo;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
class PostServiceTest {

    @Autowired
    private PostService postService;

    @Autowired
    private PostRepo postRepo;

    @BeforeEach
    void cleanDB() {
        postRepo.deleteAll(); // 각 테스트 전 DB 초기화
    }

    @Test
    @Transactional
    void 게시글_생성_및_조회_테스트() {
        // given
        PostDTO postDTO = PostDTO.builder()
                .title("test title 1")
                .contents("test content 1")
                .build();

        PostDTO created = postService.createPost(postDTO);

        // when
        PostDTO fetched = postService.lookUpPost(created.id());

        // then
        assertThat(fetched.title()).isEqualTo(postDTO.title());
        assertThat(fetched.contents()).isEqualTo(postDTO.contents());
        assertThat(fetched.id()).isEqualTo(created.id());
    }
}