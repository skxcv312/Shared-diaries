package org.zerock.study.domain.DTO;

import lombok.Builder;

@Builder
public record LoginRequest(
        String email,
        String password
){}
