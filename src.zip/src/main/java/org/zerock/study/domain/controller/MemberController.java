package org.zerock.study.domain.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.zerock.study.domain.DTO.LoginRequest;
import org.zerock.study.domain.DTO.SignupRequest;

@RestController()
@RequestMapping("/api")
@RequiredArgsConstructor
public class MemberController {

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {


        return null;
    }

    @PostMapping("/signup")
    public ResponseEntity<?> signUp(@RequestBody SignupRequest signupRequest) {
        return null;
    }

    @GetMapping("/logout")
    public ResponseEntity<?> logout() {
        return null;
    }

    @GetMapping("/unsubscript")
    public ResponseEntity<?> unsubscript() {
        return null;
    }


}
