package org.zerock.study.domain.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.zerock.study.domain.DTO.PostDTO;
import org.zerock.study.global.BaseTimeEntity;


@Entity
@Getter
@NoArgsConstructor
public class Post extends BaseTimeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String contents;

    @Builder
    public Post(String title, String content) {
        this.title = title;
        this.contents = content;
    }

    public PostDTO toDTO(){
        return PostDTO.builder()
                .id(this.id)
                .contents(this.contents)
                .title(this.title)
                .build();
    }
}
