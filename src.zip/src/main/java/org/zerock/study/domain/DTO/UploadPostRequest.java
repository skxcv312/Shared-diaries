package org.zerock.study.domain.DTO;

import lombok.Builder;

@Builder
public record UploadPostRequest(
        String title,
        String contents
){}