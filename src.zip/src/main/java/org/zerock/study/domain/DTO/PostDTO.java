package org.zerock.study.domain.DTO;

import lombok.Builder;

@Builder
public record PostDTO (
        Long id,
        String title,
        String contents
){}
