package org.zerock.study.domain.service;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.zerock.study.domain.DTO.PostDTO;
import org.zerock.study.domain.entity.Post;
import org.zerock.study.domain.repository.PostRepo;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PostService {
    private final PostRepo postRepo;

    // 게시글 생성
    public PostDTO createPost(PostDTO postDTO) {
        Post post = Post.builder()
                .title(postDTO.title())
                .content(postDTO.contents())
                .build();
        return postRepo.save(post).toDTO();
    }

    // 게시글 조회
    public PostDTO lookUpPost(Long post_id){
        Post post = postRepo.findById(post_id).orElseThrow(() ->new IllegalArgumentException("post id is not found"));
        return post.toDTO();
    }
}
