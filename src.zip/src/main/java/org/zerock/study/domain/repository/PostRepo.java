package org.zerock.study.domain.repository;

import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.zerock.study.domain.DTO.PostDTO;
import org.zerock.study.domain.entity.Post;

@Repository
public interface PostRepo extends JpaRepository<Post, Long> {
    PostDTO findByTitle(String title);

}
