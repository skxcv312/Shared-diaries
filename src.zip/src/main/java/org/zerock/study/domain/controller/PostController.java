package org.zerock.study.domain.controller;


import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.Parameter;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.study.domain.DTO.PostDTO;
import org.zerock.study.domain.DTO.UploadPostRequest;
import org.zerock.study.domain.entity.Post;
import org.zerock.study.domain.service.PostService;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/post")
public class PostController {
    private final PostService postService;

    @PostMapping("/upload")
    public ResponseEntity<?> uploadPost(UploadPostRequest uploadPostRequest) {
        PostDTO postDTO = PostDTO.builder()
                .title(uploadPostRequest.title())
                .contents(uploadPostRequest.contents())
                .build();

        PostDTO newPost = postService.createPost(postDTO);

        return ResponseEntity.ok().body(newPost);
    }

    @PostMapping()
    public ResponseEntity<?> viewPost(@RequestParam("id") Long post_id){
        PostDTO postDTO = postService.lookUpPost(post_id);

        return ResponseEntity.ok().body(postDTO);
    }

}
